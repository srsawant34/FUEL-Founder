package com.example.fuu;


import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class Overview extends AppCompatActivity
{

    ViewPager viewPager;
    //  LinearLayout sliderdots;
    private int dotscount;
    private ImageView[] dots;
    private Timer timer;
    int current_position = 0;
    int counter = 0;
    ImageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_overview);

        viewPager = (ViewPager)findViewById(R.id.viewpage);
        adapter = new ImageAdapter(this);
        viewPager.setAdapter(adapter);
        int  dotscount = adapter.getCount();
        dots = new ImageView[dotscount];
        slideshow();

        TextView textView10 = (TextView) findViewById(R.id.legend);
        Typeface typeface10 = Typeface.createFromAsset(getAssets(), "Ubuntu-B.ttf");
        textView10.setTypeface(typeface10);

        MyListData[] myListData  =new MyListData[]
                {
                        new MyListData("Ketan Deshpande is Ashoka fellow , Founder & CEO of a non profit Organization FUEL (Friends union Energizing Lives)a credible non-profit engaged in providing career counselling and assistance, scholarships & skill building of youth.",R.drawable.arrow),
                        new MyListData("Ketan is also Pavate Fellow at Cambridge University, UK & had represented at Global Entrepreneurship Summit (GES), 2016 at Stanford University, USA which was hosted by Former President Obama.",R.drawable.arrow),
                        new MyListData("Fuel is doing Career Counselling to 63,000 children of Army personnel through Edu Raksha project and for police personnel with support of leading CSR like HDFC Bank, Hero Motocorp",R.drawable.arrow),
                        new MyListData("Financial assistance and support for higher education through connects and implementation of scholarship programs for needy and meritorious girl students.",R.drawable.arrow),
                        new MyListData("FUEL runs CGSC (Career Guidance & Skilling centers) in India for needy youth and wish to replicate the model in 600 + districts of india.",R.drawable.arrow),
                        new MyListData("Ketan was awarded as Champions of Change-2017 by Hon'ble PM of India at Niti Aayog.",R.drawable.arrow),
                        new MyListData("FUEL is Innovation partner of NSDC & SOI partner of Niti Aayog has reached upto 1 million students and successfully operating in India and expanded its operations to other countries in Africa since last 10 years.",R.drawable.arrow),
                        new MyListData("FUEL has implemented large CSR projects in areas of Career Counselling, Skill development and Scholarships for Defence personnel Children and rural youth though companies.",R.drawable.arrow),



                };
        RecyclerView recyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        MyListAdapter myListAdapter = new MyListAdapter(myListData);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        //  recyclerView.ser
        recyclerView.setAdapter(myListAdapter);

        //NEXT activity

       /* public void onClick(View view)
        {
            Intent intent = new Intent(MainActivity.this,KetanOverview.class);
            startActivity(intent);
        }*/


         /*     for (int i=0;i<dotscount;i++)
        {
            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.nonactive_dot));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8,0,8,0);
            sliderdots.addView(dots[i],params);
        }
        dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.active_dot));
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i)
            {
                for(int j=0;j<dotscount;j++)
                {
                    dots[j].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.nonactive_dot));

                }
                dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.active_dot));
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }*/
        //});

        FloatingActionButton fabo = (FloatingActionButton)findViewById(R.id.fabo);
        fabo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent intent = new Intent(Overview.this, Special.class);
                startActivity(intent);
            }
        });








    }

    private void slideshow()
    {
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable()
        {
            @Override
            public void run()
            {
                viewPager.setCurrentItem(counter++,true);
                if (counter==4)
                {
                    counter=0;
                    viewPager.setCurrentItem(counter,true);

                }

                //  counter++;
                //dots = new ImageView[0];
              /*  if (counter==3)
                {
                    //viewPager.setAdapter(adapter);
                    dots = new ImageView[0];
                    counter = 0;
                    //viewPager.setAdapter(adapter);

                }*/




            }

        };
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run()
            {
                handler.post(runnable);

            }
        },250,2000);
    }

    public void NextMain(View view) {
        Intent intent =new Intent(Overview.this,MainActivity.class);
        startActivity(intent);
    }

   /* public void Onclick1(View view)
    {
        Intent intent1 = new Intent(KetanOverview.this,Achievements.class);
        startActivity(intent1);
    }*/


}
