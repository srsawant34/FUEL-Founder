package com.example.fuu;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Awards extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_awards);

        TextView textView = (TextView) findViewById(R.id.la1);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "Ubuntu-M.ttf");
        textView.setTypeface(typeface);

        TextView textView2 = (TextView) findViewById(R.id.la2);
        textView2.setTypeface(typeface);

        TextView textView3 = (TextView)findViewById(R.id.la3);
        textView3.setTypeface(typeface);

        TextView textView4 = (TextView)findViewById(R.id.la4);
        textView4.setTypeface(typeface);

        TextView textView5 = (TextView)findViewById(R.id.la5);
        textView5.setTypeface(typeface);

        TextView textView6 = (TextView)findViewById(R.id.la6);
        textView6.setTypeface(typeface);

        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab_to_con);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent intent = new Intent(Awards.this, Contact.class);
                startActivity(intent);
            }
        });
    }

    public void NextAchievements(View view)
    {
        Intent intent = new Intent(Awards.this,Special.class);
        startActivity(intent);
    }
}
