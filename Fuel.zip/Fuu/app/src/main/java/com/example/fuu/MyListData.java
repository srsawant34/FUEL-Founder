package com.example.fuu;

public class MyListData
{
    private String data;
    private int id;
    public MyListData(String data,int id)
    {
        this.data = data;
        this.id = id;
    }
    public void setData(String data)
    {
        this.data = data;
    }

    public String getData()
    {
        return data;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

}
