package com.example.fuu;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = (TextView)findViewById(R.id.text);
        Typeface typeface = Typeface.createFromAsset(getAssets(),"Ubuntu-Bold.ttf");
        textView.setTypeface(typeface);

        TextView textView1 = (TextView)findViewById(R.id.text1);
        Typeface typeface1 = Typeface.createFromAsset(getAssets(),"Ubuntu-Light.ttf");
        textView1.setTypeface(typeface1);




    }


    public void onClick(View view)
    {
        Intent intent = new Intent(MainActivity.this,Overview.class);
        startActivity(intent);
    }



}


