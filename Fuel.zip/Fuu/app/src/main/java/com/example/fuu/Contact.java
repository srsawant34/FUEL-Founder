package com.example.fuu;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Contact extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        TextView textView9 = (TextView) findViewById(R.id.contact);
        Typeface typeface9 = Typeface.createFromAsset(getAssets(), "Ubuntu-B.ttf");
        textView9.setTypeface(typeface9);

        TextView textView10 = (TextView) findViewById(R.id.phone);
        Typeface typeface10 = Typeface.createFromAsset(getAssets(), "Ubuntu-M.ttf");
        textView10.setTypeface(typeface10);

        TextView textView11 = (TextView) findViewById(R.id.email);
        textView11.setTypeface(typeface10);

        TextView textView12 = (TextView) findViewById(R.id.web);
        textView12.setTypeface(typeface10);

        TextView textView13 = (TextView) findViewById(R.id.addr);
        textView13.setTypeface(typeface10);

        TextView textView14 = (TextView) findViewById(R.id.no);
        Typeface typeface14 = Typeface.createFromAsset(getAssets(), "Ubuntu-L.ttf");
        textView14.setTypeface(typeface14);

        TextView textView15 = (TextView) findViewById(R.id.em);
        textView15.setTypeface(typeface14);

        TextView textView16 = (TextView) findViewById(R.id.waddr);
        textView16.setTypeface(typeface14);

        TextView textView17 = (TextView) findViewById(R.id.add);
        textView17.setTypeface(typeface14);

    }

    public void NextHonors(View view) {
        Intent intent = new Intent(Contact.this,Awards.class);
        startActivity(intent);

    }
}
