package com.example.fuu;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Special extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_special);

        TextView textView = (TextView) findViewById(R.id.l1);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "Ubuntu-L.ttf");
        textView.setTypeface(typeface);

        TextView textView2 = (TextView) findViewById(R.id.l2);
        textView2.setTypeface(typeface);

        TextView textView3 = (TextView)findViewById(R.id.l3);
        textView3.setTypeface(typeface);

        TextView textView4 = (TextView)findViewById(R.id.l4);
        textView4.setTypeface(typeface);

        TextView textView5 = (TextView)findViewById(R.id.l5);
        textView5.setTypeface(typeface);

        TextView textView6 = (TextView)findViewById(R.id.l6);
        textView6.setTypeface(typeface);

        TextView textView7 = (TextView)findViewById(R.id.l7);
        textView7.setTypeface(typeface);

        TextView textView8 = (TextView)findViewById(R.id.l8);
        textView8.setTypeface(typeface);


        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent intent = new Intent(Special.this, Awards.class);
                startActivity(intent);
            }
        });
    }

    public void NextAbout(View view) {
        Intent intent  = new Intent(Special.this,Overview.class);
        startActivity(intent);
    }
}
